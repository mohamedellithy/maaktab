<h2>مرحبا  {{ $data['firstname'].' '.$data['lastname'] }}</h2> 
<br>

<strong  style="text-align: center"> هذة رسالة تأكيد على تلقي طلب تواصلك و استفسارك من قبل المسؤلين و سيتم الرد عليك فى غضون 24 ساعة من الان </strong> <br>
<br/>

شكرا لك 