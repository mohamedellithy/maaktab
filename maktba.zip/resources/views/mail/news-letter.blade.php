<h2>طلب الاشتراك فى النشرة البريدية</h2> 
<br>
    <strong  style="text-align: center"> 
        يريد 
        <br/>
        {{ $data['email'] }}
        <br>
        الاشتراك فى النشرة البريدية لدينا
    </strong> <br>
<br/>

شكرا لك 