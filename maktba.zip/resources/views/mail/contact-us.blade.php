<h2>Hey, It's me {{ $data['fullName'] }}</h2> 
<br>
    
<strong>User details: </strong><br>
<strong>Name: </strong>{{ $data['fullName']  }} <br>
<strong>Email: </strong>{{ $data['email']  }} <br>
<strong>Phone: </strong>{{ $data['phone']}} <br>
<strong>Message: </strong>{{ $data['description']  }} <br><br>
شكرا لك