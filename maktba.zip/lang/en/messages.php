<?php

return [
    'Reset Password Notification' => 'إعادة تعيين كلمة المرور',
    'You are receiving this email because we received a password reset request for your account.' => 'أنت تتلقى هذا البريد الإلكتروني لأننا تلقينا طلب إعادة تعيين كلمة المرور لحسابك.',
    'Reset Password' => 'إعادة تعيين كلمة المرور',
    'This password reset link will expire in :count minutes' => 'ستنتهي صلاحية رابط إعادة تعيين كلمة المرور في :count الدقائق',
    'If you\'re having trouble clicking the "Reset Password" button, copy and paste the URL below into your web browser:' => 'إذا كنت تواجه مشكلة في النقر فوق الزر "إعادة تعيين كلمة المرور" ، فانسخ عنوان URL أدناه والصقه في متصفح الويب لديك:'

];
