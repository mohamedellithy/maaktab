<?php 

return [
    'pending'     => 'منتظر الرد',
    'progress' => 'قيد التنفيذ',
    'completed'   => 'مكتمل',
    'refused'     => 'مرفوض',
    'cancelled'   => 'ملغي',
    'success'     =>'ناجحة',
    'failed'      => 'غير ناجحة',
    'accepted'    => 'مقبولة',
    'wait'        => 'منتظرة'

];